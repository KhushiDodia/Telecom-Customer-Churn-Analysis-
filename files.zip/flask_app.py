# ============================================================
#  app.py  —  Flask Backend for Churn Prediction Web App
#  
#  What this file does:
#  1. Starts the Flask web server
#  2. Shows the home page (index.html) when user visits the site
#  3. Receives customer data from the form
#  4. Loads the trained ML model
#  5. Makes a prediction and sends result back to the webpage
# ============================================================

# ── Step 1: Import Libraries ─────────────────────────────────
from flask import Flask, render_template, request, jsonify
# Flask      → the web framework
# render_template → loads our HTML files
# request    → reads data sent from the form
# jsonify    → converts Python dict to JSON (for sending back to browser)

import pickle          # to load our saved ML model
import numpy as np     # for number handling
import pandas as pd    # for creating the input dataframe


# ── Step 2: Create Flask App ─────────────────────────────────
app = Flask(__name__)
# This creates our web application
# __name__ tells Flask where to look for files


# ── Step 3: Load the Saved ML Model ─────────────────────────
# We trained and saved these in our main project
model   = pickle.load(open('churn_model.pkl', 'rb'))   # Random Forest model
scaler  = pickle.load(open('scaler.pkl',      'rb'))   # StandardScaler
columns = pickle.load(open('columns.pkl',     'rb'))   # Feature column names
# 'rb' means "read binary" — pickle files are in binary format


# ── Step 4: Define Routes ────────────────────────────────────
# A "route" is a URL path. When user visits that URL, Flask runs
# the function below it.

@app.route('/')                        # URL: http://localhost:5000/
def home():
    """Show the main prediction page"""
    return render_template('index.html')
    # This loads templates/index.html and shows it in the browser


@app.route('/predict', methods=['POST'])   # URL: /predict  (only accepts POST)
def predict():
    """
    This function runs when user clicks the Predict button.
    It:
    1. Reads all form values
    2. Converts them to the right format
    3. Scales them using our scaler
    4. Makes a prediction using our model
    5. Returns the result as JSON
    """

    # ── Read form data ───────────────────────────────────────
    # request.form contains all the values user filled in
    data = request.form

    # ── Build a blank input row with all features = 0 ────────
    input_data = {col: 0 for col in columns}

    # ── Fill in numerical values directly ────────────────────
    input_data['tenure']         = float(data.get('tenure', 0))
    input_data['MonthlyCharges'] = float(data.get('MonthlyCharges', 0))
    input_data['TotalCharges']   = float(data.get('TotalCharges', 0))
    input_data['SeniorCitizen']  = int(data.get('SeniorCitizen', 0))

    # ── Fill in one-hot encoded (Yes/No) features ─────────────
    # Our model was trained with get_dummies(drop_first=True)
    # So each category becomes a 0 or 1 column
    def set_if(col, value, field):
        """Helper: set input_data[col] = 1 if form field equals value"""
        if data.get(field) == value and col in input_data:
            input_data[col] = 1

    set_if('gender_Male',                       'Male',                   'gender')
    set_if('Partner_Yes',                       'Yes',                    'Partner')
    set_if('Dependents_Yes',                    'Yes',                    'Dependents')
    set_if('PhoneService_Yes',                  'Yes',                    'PhoneService')
    set_if('MultipleLines_No phone service',    'No phone service',       'MultipleLines')
    set_if('MultipleLines_Yes',                 'Yes',                    'MultipleLines')
    set_if('InternetService_Fiber optic',       'Fiber optic',            'InternetService')
    set_if('InternetService_No',                'No',                     'InternetService')
    set_if('OnlineSecurity_No internet service','No internet service',    'OnlineSecurity')
    set_if('OnlineSecurity_Yes',                'Yes',                    'OnlineSecurity')
    set_if('OnlineBackup_No internet service',  'No internet service',    'OnlineBackup')
    set_if('OnlineBackup_Yes',                  'Yes',                    'OnlineBackup')
    set_if('DeviceProtection_No internet service','No internet service',  'DeviceProtection')
    set_if('DeviceProtection_Yes',              'Yes',                    'DeviceProtection')
    set_if('TechSupport_No internet service',   'No internet service',    'TechSupport')
    set_if('TechSupport_Yes',                   'Yes',                    'TechSupport')
    set_if('StreamingTV_No internet service',   'No internet service',    'StreamingTV')
    set_if('StreamingTV_Yes',                   'Yes',                    'StreamingTV')
    set_if('StreamingMovies_No internet service','No internet service',   'StreamingMovies')
    set_if('StreamingMovies_Yes',               'Yes',                    'StreamingMovies')
    set_if('Contract_One year',                 'One year',               'Contract')
    set_if('Contract_Two year',                 'Two year',               'Contract')
    set_if('PaperlessBilling_Yes',              'Yes',                    'PaperlessBilling')
    set_if('PaymentMethod_Credit card (automatic)', 'Credit card (automatic)', 'PaymentMethod')
    set_if('PaymentMethod_Electronic check',    'Electronic check',       'PaymentMethod')
    set_if('PaymentMethod_Mailed check',        'Mailed check',           'PaymentMethod')

    # ── Convert to DataFrame (model expects this format) ──────
    X = pd.DataFrame([input_data])[columns]

    # ── Scale the input using our saved scaler ────────────────
    X_scaled = scaler.transform(X)

    # ── Make Prediction ───────────────────────────────────────
    prediction = model.predict(X_scaled)[0]          # 0 = Stay, 1 = Churn
    probability = model.predict_proba(X_scaled)[0]   # [prob_stay, prob_churn]

    churn_prob = round(float(probability[1]) * 100, 2)
    stay_prob  = round(float(probability[0]) * 100, 2)

    # ── Determine Risk Level ──────────────────────────────────
    if churn_prob >= 70:
        risk = "High Risk"
    elif churn_prob >= 40:
        risk = "Medium Risk"
    else:
        risk = "Low Risk"

    # ── Build Recommendations ─────────────────────────────────
    tips = []
    if data.get('Contract') == 'Month-to-month':
        tips.append("Offer discount for switching to a 1 or 2-year contract")
    if float(data.get('MonthlyCharges', 0)) > 70:
        tips.append("Monthly charges are high — offer a loyalty discount")
    if float(data.get('tenure', 0)) < 12:
        tips.append("New customer — assign dedicated onboarding support")
    if data.get('TechSupport') == 'No':
        tips.append("Offer free Tech Support upgrade for 3 months")
    if data.get('OnlineSecurity') == 'No':
        tips.append("Offer Online Security as a free add-on")
    if data.get('PaymentMethod') == 'Electronic check':
        tips.append("Encourage switching to automatic payment method")
    if not tips:
        tips.append("Send a satisfaction survey and loyalty reward offer")

    # ── Send Result Back to Frontend ──────────────────────────
    return jsonify({
        'prediction':  int(prediction),     # 0 or 1
        'churn_prob':  churn_prob,           # e.g. 73.5
        'stay_prob':   stay_prob,            # e.g. 26.5
        'risk':        risk,                 # "High Risk" etc.
        'tips':        tips                  # list of recommendations
    })
    # jsonify converts this Python dict to JSON
    # The browser's JavaScript reads this and updates the page


# ── Step 5: Run the App ──────────────────────────────────────
if __name__ == '__main__':
    app.run(debug=True)
    # debug=True → shows errors in browser, auto-reloads on code change
    # Visit: http://localhost:5000 to see your app!
